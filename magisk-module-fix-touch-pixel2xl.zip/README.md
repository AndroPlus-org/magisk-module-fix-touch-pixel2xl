#### Fix touch on Pixel 2 XL

This module attempt to fix touch problem on Pixel 2 XL (taimen).
Tested on Android 8.1 Oreo ROM.

#### How does it works?

This module replaces "/system/vendor/usr/idc/touchscreen.idc" to modified one.

#### NOTICE

* You should use latest Magisk Manager to install this module. If you meet any problem under installation from Magisk Manager, please try to install it from recovery.

#### Credit

* The original modified file is made by [showlyshah](https://forum.xda-developers.com/pixel-2-xl/how-to/fix-touch-screen-issue-t3723717).

## Change log

#### v01
* Initial Release